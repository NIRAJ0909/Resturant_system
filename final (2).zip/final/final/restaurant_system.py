import os
import ast
from datetime import datetime

class RestaurantSystem:
    def __init__(self):
        self.current_user = None
        self.login_attempts = 0
        self.users_file = "users.txt"
        self.orders_file = "orders.txt"
        self.menu_file = "menu.txt"
        self.feedback_file = "feedback.txt"
        self.ingredients_file = "ingredients.txt"

        # Create files if they don't exist
        for file in [self.users_file, self.orders_file, self.menu_file,
                    self.feedback_file, self.ingredients_file]:
            if not os.path.exists(file):
                with open(file, 'w') as f:
                    f.write('[]')

        # Create default users if users file is empty
        users = self.load_data(self.users_file)
        if not users:
            users.extend([
                {'username': 'admin', 'password': 'admin123', 'role': 'admin'},
                {'username': 'customer', 'password': 'customer123', 'role': 'customer'},
                {'username': 'chef', 'password': 'chef123', 'role': 'chef'},
                {'username': 'manager', 'password': 'manager123', 'role': 'manager'}
            ])
            self.save_data(self.users_file, users)

        # Create default menu items if menu file is empty
        menu = self.load_data(self.menu_file)
        if not menu:
            default_menu = [
                {'name': 'Burger', 'price': 9.99, 'category': 'Main Course'},
                {'name': 'Pizza', 'price': 12.99, 'category': 'Main Course'},
                {'name': 'Salad', 'price': 7.99, 'category': 'Appetizer'},
                {'name': 'Ice Cream', 'price': 4.99, 'category': 'Dessert'},
                {'name': 'Chicken Wings', 'price': 8.99, 'category': 'Appetizer'},
                {'name': 'Pasta', 'price': 11.99, 'category': 'Main Course'},
                {'name': 'Fish and Chips', 'price': 13.99, 'category': 'Main Course'},
                {'name': 'Caesar Salad', 'price': 8.99, 'category': 'Appetizer'},
                {'name': 'Chocolate Cake', 'price': 6.99, 'category': 'Dessert'},
                {'name': 'Garlic Bread', 'price': 4.99, 'category': 'Appetizer'},
                {'name': 'Steak', 'price': 24.99, 'category': 'Main Course'},
                {'name': 'Cheesecake', 'price': 7.99, 'category': 'Dessert'}
            ]
            self.save_data(self.menu_file, default_menu)

    def load_data(self, filename):
        try:
            with open(filename, 'r') as f:
                content = f.read().strip()
                return ast.literal_eval(content) if content else []
        except:
            return []

    def save_data(self, filename, data):
        with open(filename, 'w') as f:
            f.write(repr(data))

    def login(self, username, password):
        if self.login_attempts >= 3:
            print("Maximum login attempts exceeded. Please try again later.")
            return False

        users = self.load_data(self.users_file)
        for user in users:
            if user['username'] == username and user['password'] == password:
                self.current_user = user
                self.login_attempts = 0
                return True

        self.login_attempts += 1
        return False

    def get_menu(self):
        return self.load_data(self.menu_file)

    def add_user(self, username, password, role):
        if not self.current_user or self.current_user['role'] not in ['admin', 'manager']:
            return False
            
        # Manager can only add customers
        if self.current_user['role'] == 'manager' and role != 'customer':
            return False
            
        users = self.load_data(self.users_file)
        
        # Check if username already exists
        if any(user['username'] == username for user in users):
            return False
            
        users.append({
            'username': username,
            'password': password,
            'role': role
        })
        self.save_data(self.users_file, users)
        return True

    def place_order(self, items):
        if not self.current_user or self.current_user['role'] != 'customer':
            return False
            
        orders = self.load_data(self.orders_file)
        order = {
            'order_id': len(orders) + 1,
            'customer': self.current_user['username'],
            'items': items,
            'status': 'pending',
            'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'total_price': sum(item['price'] * item['quantity'] for item in items),
            'chef_assigned': False,
            'completed_time': None
        }
        orders.append(order)
        self.save_data(self.orders_file, orders)
        return True

    def update_order_status(self, order_id, status):
        if not self.current_user or self.current_user['role'] not in ['chef', 'admin']:
            return False
            
        orders = self.load_data(self.orders_file)
        for order in orders:
            if order['order_id'] == order_id:
                order['status'] = status
                if status == 'preparing':
                    order['chef_assigned'] = True
                elif status == 'completed':
                    order['completed_time'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                self.save_data(self.orders_file, orders)
                return True
        return False

    def start_preparing_order(self, order_id):
        if not self.current_user or self.current_user['role'] != 'chef':
            return False
            
        orders = self.load_data(self.orders_file)
        for order in orders:
            if order['order_id'] == order_id and order['status'] == 'pending':
                order['status'] = 'preparing'
                order['chef_assigned'] = True
                order['preparation_start_time'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                self.save_data(self.orders_file, orders)
                return True
        return False

    def get_orders(self, status=None):
        orders = self.load_data(self.orders_file)
        if status:
            return [order for order in orders if order['status'] == status]
        return orders

    def delete_order(self, order_id):
        if not self.current_user or self.current_user['role'] != 'admin':
            return False
            
        orders = self.load_data(self.orders_file)
        orders = [order for order in orders if order['order_id'] != order_id]
        self.save_data(self.orders_file, orders)
        return True

    def cancel_order(self, order_id):
        if not self.current_user or self.current_user['role'] != 'customer':
            return False
            
        orders = self.load_data(self.orders_file)
        for order in orders:
            if (order['order_id'] == order_id and 
                order['customer'] == self.current_user['username'] and 
                order['status'] == 'pending'):
                order['status'] = 'cancelled'
                order['cancelled_time'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                self.save_data(self.orders_file, orders)
                return True
        return False

    def update_profile(self, new_password):
        if not self.current_user:
            return False
            
        users = self.load_data(self.users_file)
        for user in users:
            if user['username'] == self.current_user['username']:
                user['password'] = new_password
                self.current_user = user
                self.save_data(self.users_file, users)
                return True
        return False

    def give_feedback(self, rating, comment):
        if not self.current_user or self.current_user['role'] != 'customer':
            return False
            
        feedback = self.load_data(self.feedback_file)
        new_feedback = {
            'customer': self.current_user['username'],
            'rating': rating,
            'comment': comment,
            'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        feedback.append(new_feedback)
        self.save_data(self.feedback_file, feedback)
        return True

    def update_chef_profile(self, new_password):
        if not self.current_user or self.current_user['role'] != 'chef':
            return False
            
        users = self.load_data(self.users_file)
        for user in users:
            if user['username'] == self.current_user['username']:
                user['password'] = new_password
                self.current_user = user
                self.save_data(self.users_file, users)
                return True
        return False

    def add_ingredient(self, name, quantity, unit):
        """Add a new ingredient to the inventory."""
        if not self.current_user or self.current_user['role'] not in ['chef', 'admin']:
            return False
            
        if not name or not quantity or not unit:
            return False
            
        ingredients = self.load_data(self.ingredients_file)
        
        # Check if ingredient already exists
        for ingredient in ingredients:
            if ingredient['name'].lower() == name.lower():
                return False
        
        new_ingredient = {
            'name': name,
            'quantity': quantity,
            'unit': unit,
            'requested_by': self.current_user['username'],
            'status': 'pending',
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        ingredients.append(new_ingredient)
        self.save_data(self.ingredients_file, ingredients)
        print("\n✓ Ingredient request added successfully!")
        return True

    def edit_ingredient(self, name, quantity=None, unit=None):
        """Edit an existing ingredient."""
        if not self.current_user or self.current_user['role'] not in ['chef', 'admin']:
            return False
            
        if not name:
            return False
            
        ingredients = self.load_data(self.ingredients_file)
        
        for ingredient in ingredients:
            if ingredient['name'].lower() == name.lower():
                if quantity:
                    ingredient['quantity'] = quantity
                if unit:
                    ingredient['unit'] = unit
                ingredient['updated_by'] = self.current_user['username']
                ingredient['updated_at'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                self.save_data(self.ingredients_file, ingredients)
                print("\n✓ Ingredient request updated successfully!")
                return True
        return False

    def delete_ingredient(self, name):
        """Delete an ingredient from inventory."""
        if not self.current_user or self.current_user['role'] not in ['chef', 'admin']:
            return False
            
        if not name:
            return False
            
        ingredients = self.load_data(self.ingredients_file)
        
        for i, ingredient in enumerate(ingredients):
            if ingredient['name'].lower() == name.lower():
                ingredients.pop(i)
                self.save_data(self.ingredients_file, ingredients)
                print("\n✓ Ingredient request deleted successfully!")
                return True
        return False

    def get_ingredients(self):
        """Get the list of ingredients from the ingredients file."""
        if not self.current_user or self.current_user['role'] not in ['chef', 'admin', 'manager']:
            return None
        return self.load_data(self.ingredients_file)

    def edit_order(self, order_id, new_items):
        if not self.current_user or self.current_user['role'] != 'customer':
            return False
            
        orders = self.load_data(self.orders_file)
        for order in orders:
            if (order['order_id'] == order_id and 
                order['customer'] == self.current_user['username'] and 
                order['status'] == 'pending'):
                order['items'] = new_items
                order['total_price'] = sum(item['price'] * item['quantity'] for item in new_items)
                order['updated_at'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                self.save_data(self.orders_file, orders)
                return True
        return False

    def get_users(self):
        return self.load_data(self.users_file)

    def add_menu_item(self, name, price, category):
        if not self.current_user or self.current_user['role'] not in ['admin', 'manager']:
            return False
            
        menu = self.load_data(self.menu_file)
        
        # Check if item name already exists
        if any(item['name'].lower() == name.lower() for item in menu):
            return False
            
        menu.append({
            'name': name,
            'price': float(price),
            'category': category
        })
        self.save_data(self.menu_file, menu)
        return True

    def edit_menu_item(self, old_name, new_name, new_price, new_category):
        if not self.current_user or self.current_user['role'] not in ['admin', 'manager']:
            return False
            
        menu = self.load_data(self.menu_file)
        
        # Check if new name already exists (unless it's the same as old name)
        if new_name.lower() != old_name.lower() and any(item['name'].lower() == new_name.lower() for item in menu):
            return False
            
        for item in menu:
            if item['name'].lower() == old_name.lower():
                item['name'] = new_name
                item['price'] = float(new_price)
                item['category'] = new_category
                self.save_data(self.menu_file, menu)
                return True
        return False

    def delete_menu_item(self, name):
        if not self.current_user or self.current_user['role'] not in ['admin', 'manager']:
            return False
            
        menu = self.load_data(self.menu_file)
        original_length = len(menu)
        
        # Filter out the item to delete (case-insensitive comparison)
        menu = [item for item in menu if item['name'].lower() != name.lower()]
        
        # Check if an item was actually removed
        if len(menu) < original_length:
            self.save_data(self.menu_file, menu)
            return True
        return False

    def get_menu_categories(self):
        menu = self.load_data(self.menu_file)
        categories = set(item['category'] for item in menu)
        return list(categories)

    def edit_user(self, username, new_password=None, new_role=None):
        if not self.current_user or self.current_user['role'] not in ['admin', 'manager']:
            return False
            
        users = self.load_data(self.users_file)
        
        # Manager can only edit customers
        if self.current_user['role'] == 'manager':
            user_to_edit = next((user for user in users if user['username'] == username), None)
            if not user_to_edit or user_to_edit['role'] != 'customer':
                return False
        
        # Update user details
        updated = False
        for user in users:
            if user['username'] == username:
                if new_password:
                    user['password'] = new_password
                    updated = True
                if new_role and self.current_user['role'] == 'admin':
                    user['role'] = new_role
                    updated = True
                break
        
        if updated:
            self.save_data(self.users_file, users)
            return True
        return False

    def delete_user(self, username):
        if not self.current_user or self.current_user['role'] not in ['admin', 'manager']:
            return False
            
        users = self.load_data(self.users_file)
        user_to_delete = next((user for user in users if user['username'] == username), None)
        
        # Check if user exists
        if not user_to_delete:
            return False
            
        # Manager can only delete customers
        if self.current_user['role'] == 'manager' and user_to_delete['role'] != 'customer':
            return False
            
        users = [user for user in users if user['username'] != username]
        self.save_data(self.users_file, users)
        return True

    def get_users(self):
        return self.load_data(self.users_file)

    def get_staff(self, role=None):
        """Get all staff members or staff of a specific role."""
        if not self.current_user or self.current_user['role'] != 'admin':
            return None
        users = self.load_data(self.users_file)
        if role:
            return [user for user in users if user['role'] == role]
        return [user for user in users if user['role'] in ['manager', 'chef']]

    def add_staff(self, username, password, role):
        """Add a new staff member (manager or chef)."""
        if not self.current_user or self.current_user['role'] != 'admin':
            return False
        if role not in ['manager', 'chef']:
            return False
        return self.add_user(username, password, role)

    def edit_staff(self, username, new_password=None, new_role=None):
        """Edit a staff member's details."""
        if not self.current_user or self.current_user['role'] != 'admin':
            return False
        users = self.load_data(self.users_file)
        user = next((u for u in users if u['username'] == username), None)
        if not user or user['role'] not in ['manager', 'chef']:
            return False
        return self.edit_user(username, new_password, new_role)

    def delete_staff(self, username):
        """Delete a staff member."""
        if not self.current_user or self.current_user['role'] != 'admin':
            return False
        users = self.load_data(self.users_file)
        user = next((u for u in users if u['username'] == username), None)
        if not user or user['role'] not in ['manager', 'chef']:
            return False
        return self.delete_user(username)

    def get_sales_report(self, month=None, chef=None):
        """Get sales report filtered by month and/or chef."""
        if not self.current_user or self.current_user['role'] != 'admin':
            return None
            
        orders = self.load_data(self.orders_file)
        # Get completed orders only
        completed_orders = [order for order in orders if order['status'] == 'completed']
        
        if month:
            try:
                month = int(month)
                if not 1 <= month <= 12:
                    return None
                    
                # Filter orders by month using completed_time or timestamp
                filtered_orders = []
                for order in completed_orders:
                    try:
                        # First try completed_time, if not available use timestamp
                        date_str = order.get('completed_time') or order.get('timestamp')
                        if date_str:
                            order_date = datetime.strptime(date_str, '%Y-%m-%d %H:%M:%S')
                            if order_date.month == month:
                                filtered_orders.append(order)
                    except (ValueError, TypeError):
                        continue
                completed_orders = filtered_orders
            except (ValueError, TypeError):
                return None
        
        if chef:
            completed_orders = [
                order for order in completed_orders 
                if order.get('chef_assigned')
            ]
        
        return completed_orders

    def get_feedback(self):
        """Get all customer feedback."""
        if not self.current_user or self.current_user['role'] != 'admin':
            return None
        return self.load_data(self.feedback_file)

    def get_customers(self):
        """Get list of all customers"""
        if not self.current_user or self.current_user['role'] not in ['admin', 'manager']:
            return None
        users = self.load_data(self.users_file)
        return [user for user in users if user['role'] == 'customer']

    def add_customer(self, username, password):
        """Add a new customer"""
        return self.add_user(username, password, 'customer')

    def edit_customer(self, username, new_password):
        """Edit customer details"""
        if not self.current_user or self.current_user['role'] not in ['admin', 'manager']:
            return False
        users = self.load_data(self.users_file)
        for user in users:
            if user['username'] == username and user['role'] == 'customer':
                user['password'] = new_password
                self.save_data(self.users_file, users)
                return True
        return False

    def delete_customer(self, username):
        """Delete a customer"""
        if not self.current_user or self.current_user['role'] not in ['admin', 'manager']:
            return False
        users = self.load_data(self.users_file)
        filtered_users = [user for user in users if not (user['username'] == username and user['role'] == 'customer')]
        if len(filtered_users) < len(users):
            self.save_data(self.users_file, filtered_users)
            return True
        return False

def customer_menu(system):
    while True:
        print("\n=== Customer Menu ===")
        print("1. View Menu & Order")
        print("2. View My Orders")
        print("3. Cancel Order")
        print("4. Edit Order")
        print("5. Update Profile")
        print("6. Give Feedback")
        print("7. Logout")

        choice = input("\nEnter your choice (1-7): ")

        if choice == "1":
            menu = system.get_menu()
            order_items = []
            
            while True:
                print("\n=== Our Menu ===")
                # Show all items with simple numbers
                for i, item in enumerate(menu, 1):
                    print(f"{i}. {item['name']:15} ${item['price']:.2f} - {item['category']}")
                
                print("\nOptions:")
                print("0. Go Back")
                print("99. Complete Order")
                
                try:
                    choice = input(f"\nEnter item number to order (1-{len(menu)}, 0 to go back, 99 to complete): ")
                    if not choice.isdigit():
                        print("Please enter a number!")
                        continue
                        
                    choice = int(choice)
                    if choice == 0:
                        break
                    elif choice == 99:
                        if order_items:
                            print("\n=== Order Summary ===")
                            total = 0
                            for item in order_items:
                                item_total = item['price'] * item['quantity']
                                total += item_total
                                print(f"{item['name']:15} x{item['quantity']} = ${item_total:.2f}")
                            print("\n" + "=" * 35)
                            print(f"Total Order Amount: ${total:.2f}")
                            
                            confirm = input("\nConfirm order? (yes/no): ").lower()
                            if confirm == 'yes':
                                if system.place_order(order_items):
                                    print("\n✓ Order placed successfully!")
                                else:
                                    print("\n❌ Failed to place order.")
                            break
                        else:
                            print("\nNo items in order yet!")
                            continue
                        
                    if 1 <= choice <= len(menu):
                        selected_item = menu[choice - 1]
                        print(f"\nSelected: {selected_item['name']} - ${selected_item['price']:.2f}")
                        
                        quantity = input("Enter quantity (1-10): ")
                        if not quantity.isdigit() or not (1 <= int(quantity) <= 10):
                            print("Invalid quantity! Please enter a number between 1 and 10")
                            continue
                        
                        quantity = int(quantity)
                        item_to_add = selected_item.copy()
                        item_to_add['quantity'] = quantity
                        order_items.append(item_to_add)
                        print(f"\n✓ Added to cart: {quantity}x {selected_item['name']}")
                        
                        # Show current cart
                        print("\nCurrent Cart:")
                        cart_total = 0
                        for item in order_items:
                            item_total = item['price'] * item['quantity']
                            cart_total += item_total
                            print(f"- {item['name']} x{item['quantity']} = ${item_total:.2f}")
                        print(f"Cart Total: ${cart_total:.2f}")
                    else:
                        print(f"\nPlease enter a valid number!")
                except ValueError:
                    print("\nPlease enter a valid number")

        elif choice == "2":
            orders = system.get_orders()
            user_orders = [order for order in orders if order['customer'] == system.current_user['username']]
            
            if not user_orders:
                print("\nNo orders found!")
            else:
                print("\n=== Your Orders ===")
                for order in user_orders:
                    print(f"\nOrder #{order['order_id']}")
                    print(f"Status: {order['status']}")
                    print(f"Ordered on: {order['timestamp']}")
                    print("Items:")
                    for item in order['items']:
                        print(f"- {item['name']} x{item['quantity']} = ${item['price'] * item['quantity']:.2f}")
                    print(f"Total: ${order['total_price']:.2f}")
                input("\nPress Enter to continue...")

        elif choice == "3":
            orders = system.get_orders()
            pending_orders = [order for order in orders 
                            if order['customer'] == system.current_user['username'] 
                            and order['status'] == 'pending']
            
            if not pending_orders:
                print("\nNo pending orders available to cancel!")
                input("\nPress Enter to continue...")
            else:
                print("\n=== Pending Orders ===")
                # Create a mapping of selection numbers to order IDs
                order_mapping = {}
                for idx, order in enumerate(pending_orders, 1):
                    order_mapping[idx] = order['order_id']
                    print(f"\n{idx}. Order #{order['order_id']}")
                    print(f"   Ordered on: {order['timestamp']}")
                    print("   Items:")
                    for item in order['items']:
                        print(f"   - {item['name']} x{item['quantity']}")
                    print(f"   Total: ${order['total_price']:.2f}")
                
                try:
                    max_choice = len(pending_orders)
                    print(f"\nSelect an order (1-{max_choice} to cancel, 0 to go back): ")
                    choice = int(input("Enter your choice: "))
                    
                    if choice == 0:
                        continue
                    elif 1 <= choice <= max_choice:
                        order_id = order_mapping[choice]
                        print("\n1. Yes, cancel the order")
                        print("2. No, keep the order")
                        confirm = input("\nEnter your choice (1-2): ")
                        
                        if confirm == "1":
                            if system.cancel_order(order_id):
                                print("\n✓ Order cancelled successfully!")
                            else:
                                print("\n❌ Failed to cancel order. Please try again.")
                        elif confirm == "2":
                            print("\nOrder cancellation cancelled. Your order will be processed.")
                        else:
                            print("\nInvalid choice! Order will be kept.")
                    else:
                        print("\n❌ Invalid selection!")
                except ValueError:
                    print("\nPlease enter a valid number!")
                input("\nPress Enter to continue...")
                    
        elif choice == "4":
            orders = system.get_orders()
            pending_orders = [order for order in orders 
                            if order['customer'] == system.current_user['username'] 
                            and order['status'] == 'pending']
            
            if not pending_orders:
                print("\nNo pending orders available to edit!")
                input("\nPress Enter to continue...")
            else:
                print("\n=== Pending Orders Available to Edit ===")
                print(f"You have {len(pending_orders)} pending order(s)")
                print("-" * 50)
                
                # Create a mapping of selection numbers to order IDs
                order_mapping = {}
                for idx, order in enumerate(pending_orders, 1):
                    order_mapping[idx] = order['order_id']
                    print(f"\n{idx}. Order #{order['order_id']}")
                    print(f"   Ordered on: {order['timestamp']}")
                    print("   Items:")
                    for item in order['items']:
                        print(f"   - {item['name']:15} x{item['quantity']:2} = ${item['price'] * item['quantity']:.2f}")
                    print(f"   Total: ${order['total_price']:.2f}")
                    print("-" * 50)
                
                try:
                    max_choice = len(pending_orders)
                    print("\nOptions:")
                    print(f"1-{max_choice}: Select order to edit")
                    print("0: Go back to main menu")
                    choice = int(input("\nWhat would you like to do? "))
                    
                    if choice == 0:
                        continue
                    elif 1 <= choice <= max_choice:
                        order_id = order_mapping[choice]
                        selected_order = next((order for order in pending_orders if order['order_id'] == order_id), None)
                        
                        if selected_order:
                            print("\n=== Edit Order #{} ===".format(order_id))
                            print("-" * 50)
                            print("\nCurrent items in your order:")
                            total = sum(item['price'] * item['quantity'] for item in selected_order['items'])
                            for item in selected_order['items']:
                                print(f"- {item['name']:15} x{item['quantity']:2} = ${item['price'] * item['quantity']:.2f}")
                            print("-" * 50)
                            print(f"Total: ${total:.2f}")
                            
                            print("\nOptions:")
                            print("1. Update quantities")
                            print("2. Add more items")
                            print("3. Remove items")
                            print("0. Back to main menu")
                            print("\nTip: Press 4 for help with editing orders")
                            
                            choice = input("\nWhat would you like to do? (0-3): ")
                            
                            if choice == "1":
                                new_order_items = selected_order['items'].copy()
                                for item in new_order_items:
                                    print(f"\n{item['name']}:")
                                    quantity = input("Enter new quantity (1-10, 0 to remove): ")
                                    if not quantity.isdigit() or not (0 <= int(quantity) <= 10):
                                        print("Invalid quantity! Please enter a number between 1 and 10")
                                        continue
                                    
                                    quantity = int(quantity)
                                    if quantity == 0:
                                        new_order_items.remove(item)
                                    else:
                                        item['quantity'] = quantity
                                if system.edit_order(order_id, new_order_items):
                                    print("\n✓ Order updated successfully!")
                                else:
                                    print("\n❌ Failed to update order")
                            
                            elif choice == "2":
                                menu = system.get_menu()
                                new_order_items = selected_order['items'].copy()
                                
                                while True:
                                    print("\n=== Menu ===")
                                    for i, item in enumerate(menu, 1):
                                        print(f"{i}. {item['name']:15} ${item['price']:.2f} - {item['category']}")
                                    
                                    print("\nOptions:")
                                    print("0. Go Back")
                                    print("99. Complete Edit")
                                    
                                    try:
                                        choice = input(f"\nEnter item number to add (1-{len(menu)}, 0 to go back, 99 to complete): ")
                                        if not choice.isdigit():
                                            print("Please enter a number!")
                                            continue
                                            
                                        choice = int(choice)
                                        if choice == 0:
                                            break
                                        elif choice == 99:
                                            if new_order_items:
                                                print("\n=== Updated Order Summary ===")
                                                total = 0
                                                for item in new_order_items:
                                                    item_total = item['price'] * item['quantity']
                                                    total += item_total
                                                    print(f"{item['name']:15} x{item['quantity']} = ${item_total:.2f}")
                                                print("\n" + "=" * 35)
                                                print(f"Total Order Amount: ${total:.2f}")
                                                
                                                confirm = input("\nConfirm order update? (yes/no): ").lower()
                                                if confirm == 'yes':
                                                    if system.edit_order(order_id, new_order_items):
                                                        print("\n✓ Order updated successfully!")
                                                    else:
                                                        print("\n❌ Failed to update order")
                                                break
                                            else:
                                                print("\nNo items in order yet!")
                                                continue
                                            
                                        if 1 <= choice <= len(menu):
                                            selected_item = menu[choice - 1]
                                            print(f"\nSelected: {selected_item['name']} - ${selected_item['price']:.2f}")
                                            
                                            quantity = input("Enter quantity (1-10): ")
                                            if not quantity.isdigit() or not (1 <= int(quantity) <= 10):
                                                print("Invalid quantity! Please enter a number between 1 and 10")
                                                continue
                                            
                                            quantity = int(quantity)
                                            item_to_add = selected_item.copy()
                                            item_to_add['quantity'] = quantity
                                            
                                            # Check if item already exists in order
                                            existing_item = None
                                            for item in new_order_items:
                                                if item['name'] == selected_item['name']:
                                                    existing_item = item
                                                    break
                                            
                                            if existing_item:
                                                existing_item['quantity'] = quantity
                                                print(f"\n✓ Updated quantity: {quantity}x {selected_item['name']}")
                                            else:
                                                new_order_items.append(item_to_add)
                                                print(f"\n✓ Added to order: {quantity}x {selected_item['name']}")
                                            
                                            # Show current order
                                            print("\nCurrent Order:")
                                            order_total = 0
                                            for item in new_order_items:
                                                item_total = item['price'] * item['quantity']
                                                order_total += item_total
                                                print(f"- {item['name']} x{item['quantity']} = ${item_total:.2f}")
                                            print(f"Order Total: ${order_total:.2f}")
                                        else:
                                            print(f"\nPlease enter a valid number!")
                                    except ValueError:
                                        print("\nPlease enter a valid number")
                            
                            elif choice == "3":
                                new_order_items = selected_order['items'].copy()
                                for item in new_order_items:
                                    print(f"\n{item['name']}:")
                                    quantity = input("Enter new quantity (1-10, 0 to remove): ")
                                    if not quantity.isdigit() or not (0 <= int(quantity) <= 10):
                                        print("Invalid quantity! Please enter a number between 1 and 10")
                                        continue
                                    
                                    quantity = int(quantity)
                                    if quantity == 0:
                                        new_order_items.remove(item)
                                if system.edit_order(order_id, new_order_items):
                                    print("\n✓ Order removed successfully!")
                                else:
                                    print("\n❌ Failed to update order")
                            
                            else:
                                print("\nInvalid choice!")
                        else:
                            print("\nOrder not found!")
                    else:
                        print("\n❌ Invalid selection!")
                except ValueError:
                    print("\nPlease enter a valid Order #!")
                input("\nPress Enter to continue...")
                    
        elif choice == "5":
            print("\n=== Update Profile ===")
            while True:
                new_password = input("Enter new password (or 0 to go back): ")
                if new_password == "0":
                    break
                    
                if len(new_password) < 6:
                    print("Password must be at least 6 characters long!")
                    continue
                    
                confirm_password = input("Confirm new password: ")
                if new_password != confirm_password:
                    print("Passwords do not match!")
                    continue
                    
                if system.update_profile(new_password):
                    print("\n✓ Password updated successfully!")
                    break
                else:
                    print("\n❌ Failed to update password.")
                    break

        elif choice == "6":
            print("\n=== Give Feedback ===")
            try:
                rating = int(input("Rate our service (1-5): "))
                if not (1 <= rating <= 5):
                    print("Rating must be between 1 and 5!")
                    continue
                    
                comment = input("Add a comment (optional): ")
                if system.give_feedback(rating, comment):
                    print("\n✓ Thank you for your feedback!")
                else:
                    print("\n❌ Failed to submit feedback.")
                    
            except ValueError:
                print("\nPlease enter a valid rating (1-5)!")

        elif choice == "7":
            system.current_user = None
            print("Logout successfully!!")
            break
        
        else:
            print("\nInvalid choice! Please try again.")

def chef_menu(system):
    while True:
        print("\n=== Chef Menu ===")
        print("1. View New Orders")
        print("2. Update Order Status")
        print("3. Manage Ingredients")
        print("4. Update Profile")
        print("5. Logout")

        choice = input("\nEnter your choice (1-5): ")

        if choice == "1":
            orders = system.get_orders()
            if not orders:
                print("\nNo orders found!")
            else:
                print("\n=== All Orders ===")
                for order in orders:
                    print("\n" + "-" * 40)
                    print(f"Order #: {order['order_id']}")
                    print(f"Customer: {order['customer']}")
                    print(f"Status: {order['status']}")
                    print(f"Time: {order['timestamp']}")
                    print("\nItems:")
                    for item in order['items']:
                        print(f"- {item['name']} x{item['quantity']}")
                    print(f"Total: ${order['total_price']:.2f}")
                    print("-" * 40)
                input("\nPress Enter to continue...")

        elif choice == "2":
            while True:
                orders = system.get_orders()
                pending_orders = [order for order in orders if order['status'] == 'pending']
                preparing_orders = [order for order in orders if order['status'] == 'preparing']
                
                if not pending_orders and not preparing_orders:
                    print("\nNo orders to update!")
                    input("\nPress Enter to continue...")
                    break
                
                print("\n=== Update Order Status ===")
                
                option_num = 1
                order_options = []
                
                # Show pending orders
                if pending_orders:
                    print("\nPending Orders:")
                    for order in pending_orders:
                        print(f"{option_num}. Order {order['order_id']}")
                        print("   Items:")
                        for item in order['items']:
                            print(f"   - {item['name']} x{item['quantity']}")
                        print("   → Mark as PREPARING")
                        order_options.append((order['order_id'], 'preparing'))
                        option_num += 1
                
                # Show preparing orders
                if preparing_orders:
                    print("\nPreparing Orders:")
                    for order in preparing_orders:
                        print(f"{option_num}. Order {order['order_id']}")
                        print("   Items:")
                        for item in order['items']:
                            print(f"   - {item['name']} x{item['quantity']}")
                        print("   → Mark as COMPLETED")
                        order_options.append((order['order_id'], 'completed'))
                        option_num += 1
                
                print("\n0. Back to Main Menu")
                
                try:
                    choice = input("\nSelect option number: ")
                    if choice == "0":
                        break
                        
                    choice = int(choice)
                    if 1 <= choice <= len(order_options):
                        order_id, new_status = order_options[choice - 1]
                        if system.update_order_status(order_id, new_status):
                            status_msg = "being prepared" if new_status == 'preparing' else "completed"
                            print(f"\n✓ Order {order_id} is now {status_msg}")
                        else:
                            print("\n❌ Failed to update order status")
                    else:
                        print("\nInvalid option number!")
                except ValueError:
                    print("\nPlease enter a valid number!")
                
                input("\nPress Enter to continue...")
                    
        elif choice == "3":
            while True:
                print("\n=== Manage Ingredients ===")
                print("1. View Ingredients")
                print("2. Add Ingredient")
                print("3. Edit Ingredient")
                print("4. Delete Ingredient")
                print("5. Back to Main Menu")
                
                def display_ingredients():
                    ingredients = system.get_ingredients()
                    if not ingredients:
                        print("\nNo ingredient requests found!")
                        return False
                    print("\n=== Current Ingredient Requests ===")
                    for ing in ingredients:
                        print(f"\nName: {ing['name']}")
                        print(f"Quantity: {ing['quantity']} {ing['unit']}")
                        print(f"Requested by: {ing['requested_by']}")
                        print(f"Requested on: {ing.get('timestamp', 'N/A')}")
                        if ing.get('updated_by'):
                            print(f"Last updated by: {ing['updated_by']}")
                            print(f"Last updated on: {ing['updated_at']}")
                    return True
                
                ing_choice = input("\nEnter choice (1-5): ")
                
                if ing_choice == "1":
                    display_ingredients()
                    input("\nPress Enter to continue...")
                            
                elif ing_choice == "2":
                    name = input("\nIngredient name: ").strip()
                    if not name:
                        print("\n❌ Ingredient name cannot be empty!")
                        input("\nPress Enter to continue...")
                        continue
                        
                    quantity = input("Quantity (e.g., 5, little, medium): ").strip()
                    if not quantity:
                        print("\n❌ Quantity cannot be empty!")
                        input("\nPress Enter to continue...")
                        continue
                        
                    unit = input("Unit (e.g., kg, liters, pieces): ").strip()
                    if not unit:
                        print("\n❌ Unit cannot be empty!")
                        input("\nPress Enter to continue...")
                        continue
                    
                    if system.add_ingredient(name, quantity, unit):
                        print("\nUpdated ingredients list:")
                        display_ingredients()
                    else:
                        print("\n❌ Failed to add ingredient request. It may already exist.")
                    input("\nPress Enter to continue...")
                        
                elif ing_choice == "3":
                    if not display_ingredients():
                        input("\nPress Enter to continue...")
                        continue
                        
                    name = input("\nEnter ingredient name to edit: ").strip()
                    if not name:
                        print("\n❌ Ingredient name cannot be empty!")
                        input("\nPress Enter to continue...")
                        continue
                        
                    quantity = input("New quantity (e.g., 5, little, medium) or press Enter to skip: ").strip()
                    unit = input("New unit (e.g., kg, liters, pieces) or press Enter to skip: ").strip()
                    
                    if system.edit_ingredient(name, quantity, unit):
                        print("\nUpdated ingredients list:")
                        display_ingredients()
                    else:
                        print("\n❌ Failed to edit ingredient request. Make sure it exists.")
                    input("\nPress Enter to continue...")
                        
                elif ing_choice == "4":
                    if not display_ingredients():
                        input("\nPress Enter to continue...")
                        continue
                        
                    name = input("\nEnter ingredient name to delete: ").strip()
                    if not name:
                        print("\n❌ Ingredient name cannot be empty!")
                        input("\nPress Enter to continue...")
                        continue
                    
                    if system.delete_ingredient(name):
                        print("\nUpdated ingredients list:")
                        display_ingredients()
                    else:
                        print("\n❌ Failed to delete ingredient request. Make sure it exists.")
                    input("\nPress Enter to continue...")
                        
                elif ing_choice == "5":
                    break
                    
                else:
                    print("\nInvalid choice! Please try again.")

        elif choice == "4":
            print("\n=== Update Profile ===")
            while True:
                new_password = input("Enter new password (or 0 to go back): ")
                if new_password == "0":
                    break
                    
                if len(new_password) < 6:
                    print("Password must be at least 6 characters long!")
                    continue
                    
                confirm_password = input("Confirm new password: ")
                if new_password != confirm_password:
                    print("Passwords do not match!")
                    continue
                    
                if system.update_chef_profile(new_password):
                    print("\n✓ Password updated successfully!")
                    break
                else:
                    print("\n❌ Failed to update password.")
                    break

        elif choice == "5":
            system.current_user = None
            print("Logout Successfully!!")
            break
        
        else:
            print("\nInvalid choice! Please try again.")

def manager_menu(system):
    while True:
        print("\nManager Menu")
        print("1. View Menu Categories")
        print("2. Add Menu Item")
        print("3. Edit Menu Item")
        print("4. Delete Menu Item")
        print("5. View Ingredients List")
        print("6. Update Profile")
        print("7. Manage Customers")
        print("8. Logout")
        
        choice = input("Enter your choice: ")
        
        if choice == "1":
            menu = system.get_menu()
            categories = sorted(set(item['category'] for item in menu))
            print("\nMenu Categories:")
            for category in categories:
                print(f"- {category}")
                items = [item for item in menu if item['category'] == category]
                for item in items:
                    print(f"  * {item['name']} - ${item['price']:.2f}")
        
        elif choice == "2":
            name = input("Enter item name: ")
            try:
                price = float(input("Enter price: "))
                if price <= 0:
                    raise ValueError
            except ValueError:
                print("Invalid price. Please enter a positive number.")
                continue
                
            print("\nAvailable categories:")
            menu = system.get_menu()
            categories = sorted(set(item['category'] for item in menu))
            for cat in categories:
                print(f"- {cat}")
            category = input("Enter category (or new category): ")
            
            if system.add_menu_item(name, price, category):
                print("Menu item added successfully!")
            else:
                print("Failed to add menu item. Item might already exist or you don't have permission.")
        
        elif choice == "3":
            old_name = input("Enter the name of item to edit: ")
            menu = system.get_menu()
            item = next((item for item in menu if item['name'].lower() == old_name.lower()), None)
            
            if not item:
                print("Item not found!")
                continue
                
            print(f"\nCurrent values:")
            print(f"Name: {item['name']}")
            print(f"Price: ${item['price']:.2f}")
            print(f"Category: {item['category']}")
            
            new_name = input("Enter new name (or press Enter to keep current): ")
            new_name = new_name if new_name else item['name']
            
            try:
                new_price = input("Enter new price (or press Enter to keep current): ")
                new_price = float(new_price) if new_price else item['price']
                if new_price <= 0:
                    raise ValueError
            except ValueError:
                print("Invalid price. Please enter a positive number.")
                continue
            
            print("\nAvailable categories:")
            categories = sorted(set(item['category'] for item in menu))
            for cat in categories:
                print(f"- {cat}")
            new_category = input("Enter new category (or press Enter to keep current): ")
            new_category = new_category if new_category else item['category']
            
            if system.edit_menu_item(old_name, new_name, new_price, new_category):
                print("Menu item updated successfully!")
            else:
                print("Failed to update menu item. New name might already exist or you don't have permission.")
        
        elif choice == "4":
            name = input("Enter the name of item to delete: ")
            if system.delete_menu_item(name):
                print("Menu item deleted successfully!")
            else:
                print("Failed to delete menu item. Item might not exist or you don't have permission.")
        
        elif choice == "5":
            ingredients = system.get_ingredients()
            if ingredients is None:
                print("\nYou don't have permission to view ingredients!")
            elif not ingredients:
                print("\nNo ingredients in the list!")
            else:
                print("\n=== Ingredients List ===")
                for ingredient in ingredients:
                    print(f"- {ingredient['name']}: {ingredient['quantity']} {ingredient['unit']}")
            input("\nPress Enter to continue...")
        
        elif choice == "6":
            new_password = input("Enter new password: ")
            if system.update_profile(new_password):
                print("Profile updated successfully!")
            else:
                print("Failed to update profile.")
            input("\nPress Enter to continue...")
        
        elif choice == "7":
            while True:
                print("\nCustomer Management")
                print("1. View Customers")
                print("2. Add Customer")
                print("3. Edit Customer")
                print("4. Delete Customer")
                print("5. Back to Manager Menu")
                
                sub_choice = input("Enter your choice: ")
                
                if sub_choice == "1":
                    customers = system.get_customers()
                    if customers:
                        print("\nCustomer List:")
                        for customer in customers:
                            print(f"- {customer['username']}")
                    else:
                        print("No customers found or you don't have permission.")
                    input("\nPress Enter to continue...")
                
                elif sub_choice == "2":
                    username = input("Enter customer username: ")
                    password = input("Enter customer password: ")
                    if system.add_customer(username, password):
                        print("Customer added successfully!")
                    else:
                        print("Failed to add customer. Username might already exist.")
                    input("\nPress Enter to continue...")
                
                elif sub_choice == "3":
                    username = input("Enter customer username: ")
                    new_password = input("Enter new password: ")
                    if system.edit_customer(username, new_password):
                        print("Customer updated successfully!")
                    else:
                        print("Failed to update customer. Customer might not exist.")
                    input("\nPress Enter to continue...")
                
                elif sub_choice == "4":
                    username = input("Enter customer username: ")
                    if system.delete_customer(username):
                        print("Customer deleted successfully!")
                    else:
                        print("Failed to delete customer. Customer might not exist.")
                    input("\nPress Enter to continue...")
                
                elif sub_choice == "5":
                    break
                
                else:
                    print("Invalid choice. Please try again.")
        
        elif choice == "8":
            break
        
        else:
            print("Invalid choice. Please try again.")

def admin_menu(system):
    while True:
        print("\n=== Administrator Menu ===")
        print("1. Manage Staff")
        print("2. View Sales Report")
        print("3. View Customer Feedback")
        print("4. Update Profile")
        print("5. Logout")
        
        choice = input("\nEnter your choice: ")
        
        if choice == "1":
            while True:
                print("\n=== Staff Management ===")
                print("1. View All Staff")
                print("2. View Managers")
                print("3. View Chefs")
                print("4. Add Staff")
                print("5. Edit Staff")
                print("6. Delete Staff")
                print("7. Back to Main Menu")
                
                staff_choice = input("\nEnter your choice: ")
                
                if staff_choice in ["1", "2", "3"]:
                    role = None if staff_choice == "1" else "manager" if staff_choice == "2" else "chef"
                    staff = system.get_staff(role)
                    if staff:
                        print(f"\n{'All Staff' if not role else role.capitalize()} List:")
                        for member in staff:
                            print(f"\nUsername: {member['username']}")
                            print(f"Role: {member['role'].capitalize()}")
                            if member['role'] == 'chef':
                                orders = system.get_sales_report(chef=member['username'])
                                if orders:
                                    total_orders = len(orders)
                                    total_sales = sum(order['total_price'] for order in orders)
                                    print(f"Total Orders Completed: {total_orders}")
                                    print(f"Total Sales: ${total_sales:.2f}")
                    else:
                        print("\nNo staff members found!")
                
                elif staff_choice == "4":
                    username = input("\nEnter username: ")
                    password = input("Enter password: ")
                    print("\nAvailable roles:")
                    print("1. Manager")
                    print("2. Chef")
                    role_choice = input("Select role (1/2): ")
                    role = "manager" if role_choice == "1" else "chef" if role_choice == "2" else None
                    
                    if role and system.add_staff(username, password, role):
                        print(f"\n✓ {role.capitalize()} added successfully!")
                    else:
                        print("\n❌ Failed to add staff member!")
                
                elif staff_choice == "5":
                    username = input("\nEnter staff username to edit: ")
                    new_password = input("Enter new password (press Enter to skip): ").strip()
                    print("\nAvailable roles:")
                    print("1. Manager")
                    print("2. Chef")
                    print("3. Keep current role")
                    role_choice = input("Select new role (1/2/3): ")
                    new_role = None
                    if role_choice == "1":
                        new_role = "manager"
                    elif role_choice == "2":
                        new_role = "chef"
                    
                    if system.edit_staff(username, new_password, new_role):
                        print("\n✓ Staff member updated successfully!")
                    else:
                        print("\n❌ Failed to update staff member!")
                
                elif staff_choice == "6":
                    username = input("\nEnter staff username to delete: ")
                    if system.delete_staff(username):
                        print("\n✓ Staff member deleted successfully!")
                    else:
                        print("\n❌ Failed to delete staff member!")
                
                elif staff_choice == "7":
                    break
        
        elif choice == "2":
            while True:
                print("\n=== Sales Report ===")
                print("1. View All Sales")
                print("2. View Sales by Month")
                print("3. View Sales by Chef")
                print("4. Back to Main Menu")
                
                report_choice = input("\nEnter your choice: ")
                
                if report_choice == "1":
                    orders = system.get_sales_report()
                    if orders:
                        total_sales = sum(order['total_price'] for order in orders)
                        print(f"\n=== Overall Sales Report ===")
                        print(f"Total Revenue: ${total_sales:.2f}")
                        print(f"Total Orders: {len(orders)}")
                        
                        # Group orders by month
                        orders_by_month = {}
                        for order in orders:
                            try:
                                date_str = order.get('completed_time') or order.get('timestamp')
                                if date_str:
                                    order_date = datetime.strptime(date_str, '%Y-%m-%d %H:%M:%S')
                                    month_key = order_date.strftime('%B %Y')
                                    if month_key not in orders_by_month:
                                        orders_by_month[month_key] = {
                                            'orders': [],
                                            'total': 0,
                                            'count': 0
                                        }
                                    orders_by_month[month_key]['orders'].append(order)
                                    orders_by_month[month_key]['total'] += order['total_price']
                                    orders_by_month[month_key]['count'] += 1
                            except (ValueError, TypeError):
                                continue
                        
                        # Display monthly breakdown
                        print("\nMonthly Breakdown:")
                        for month, data in sorted(orders_by_month.items()):
                            print(f"\n{month}:")
                            print(f"  Revenue: ${data['total']:.2f}")
                            print(f"  Orders: {data['count']}")
                            print("  Order Details:")
                            for order in data['orders']:
                                print(f"    - Order {order['order_id']}: ${order['total_price']:.2f}")
                                print(f"      Completed: {order.get('completed_time') or 'N/A'}")
                                print("      Items:")
                                for item in order['items']:
                                    print(f"        * {item['name']} x{item['quantity']} = ${item['price'] * item['quantity']:.2f}")
                    else:
                        print("\nNo completed orders found!")
                    input("\nPress Enter to continue...")
                
                elif report_choice == "2":
                    try:
                        print("\nSelect Month:")
                        months = [
                            "January", "February", "March", "April",
                            "May", "June", "July", "August",
                            "September", "October", "November", "December"
                        ]
                        for i, month_name in enumerate(months, 1):
                            print(f"{i}. {month_name}")
                            
                        month = int(input("\nEnter month number (1-12): "))
                        if 1 <= month <= 12:
                            orders = system.get_sales_report(month=month)
                            month_name = months[month - 1]
                            
                            if orders:
                                total_sales = sum(order['total_price'] for order in orders)
                                print(f"\n=== Sales Report for {month_name} ===")
                                print(f"Total Revenue: ${total_sales:.2f}")
                                print(f"Total Orders: {len(orders)}")
                                
                                # Group by day
                                orders_by_day = {}
                                for order in orders:
                                    try:
                                        date_str = order.get('completed_time') or order.get('timestamp')
                                        if date_str:
                                            order_date = datetime.strptime(date_str, '%Y-%m-%d %H:%M:%S')
                                            day_key = order_date.strftime('%Y-%m-%d')
                                            if day_key not in orders_by_day:
                                                orders_by_day[day_key] = {
                                                    'orders': [],
                                                    'total': 0,
                                                    'count': 0
                                                }
                                            orders_by_day[day_key]['orders'].append(order)
                                            orders_by_day[day_key]['total'] += order['total_price']
                                            orders_by_day[day_key]['count'] += 1
                                    except (ValueError, TypeError):
                                        continue
                                
                                if orders_by_day:
                                    print("\nDaily Breakdown:")
                                    for day, data in sorted(orders_by_day.items()):
                                        print(f"\n{day}:")
                                        print(f"  Revenue: ${data['total']:.2f}")
                                        print(f"  Orders: {data['count']}")
                                        print("  Order Details:")
                                        for order in data['orders']:
                                            print(f"    - Order {order['order_id']}: ${order['total_price']:.2f}")
                                            print(f"      Completed: {order.get('completed_time') or 'N/A'}")
                                            print("      Items:")
                                            for item in order['items']:
                                                print(f"        * {item['name']} x{item['quantity']} = ${item['price'] * item['quantity']:.2f}")
                                else:
                                    print("\nNo daily breakdown available.")
                            else:
                                print(f"\nNo completed orders found for {month_name}!")
                        else:
                            print("\nInvalid month! Please enter a number between 1 and 12.")
                    except ValueError:
                        print("\nInvalid input! Please enter a number.")
                    input("\nPress Enter to continue...")
                
                elif report_choice == "3":
                    chefs = system.get_staff("chef")
                    if chefs:
                        print("\nAvailable Chefs:")
                        for i, chef in enumerate(chefs, 1):
                            print(f"{i}. {chef['username']}")
                        try:
                            choice = int(input("\nSelect chef number: "))
                            if 1 <= choice <= len(chefs):
                                chef_username = chefs[choice-1]['username']
                                orders = system.get_sales_report(chef=chef_username)
                                if orders:
                                    total_sales = sum(order['total_price'] for order in orders)
                                    print(f"\nTotal Sales by Chef {chef_username}: ${total_sales:.2f}")
                                    print(f"Total Orders: {len(orders)}")
                                    print("\nOrder Details:")
                                    for order in orders:
                                        print(f"\nOrder ID: {order['order_id']}")
                                        print(f"Date: {order['timestamp']}")
                                        print(f"Total: ${order['total_price']:.2f}")
                                else:
                                    print(f"\nNo completed orders found for chef {chef_username}!")
                            else:
                                print("\nInvalid choice!")
                        except ValueError:
                            print("\nInvalid input! Please enter a number.")
                    else:
                        print("\nNo chefs found in the system!")
                
                elif report_choice == "4":
                    break
        
        elif choice == "3":
            feedback = system.get_feedback()
            if feedback:
                print("\n=== Customer Feedback ===")
                for item in feedback:
                    print(f"\nCustomer: {item['customer']}")
                    print(f"Date: {item['timestamp']}")
                    print(f"Rating: {item['rating']}/5")
                    print(f"Comment: {item['comment']}")
            else:
                print("\nNo feedback found!")
            input("\nPress Enter to continue...")
        
        elif choice == "4":
            new_password = input("\nEnter new password: ")
            if system.update_profile(new_password):
                print("\n✓ Profile updated successfully!")
            else:
                print("\n❌ Failed to update profile!")
            input("\nPress Enter to continue...")
        
        elif choice == "5":
            break
        
        else:
            print("\nInvalid choice! Please try again.")

def main():
    system = RestaurantSystem()

    while True:
        print("\n=== Restaurant Management System ===")
        print("1. Login")
        print("2. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            username = input("Username: ")
            password = input("Password: ")

            if system.login(username, password):
                print(f"\nWelcome {username}!")
                if system.current_user['role'] == 'customer':
                    customer_menu(system)
                elif system.current_user['role'] == 'chef':
                    chef_menu(system)
                elif system.current_user['role'] == 'manager':
                    manager_menu(system)
                elif system.current_user['role'] == 'admin':
                    admin_menu(system)
            else:
                print("Invalid credentials!")

        elif choice == "2":
            print("Thank you for using the system!")
            break

if __name__ == "__main__":
    main()
